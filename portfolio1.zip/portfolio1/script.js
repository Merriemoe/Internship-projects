// Reorder cards so clicked one becomes first and big
const grid = document.querySelector('.studio-grid');

document.querySelectorAll('.studio-card').forEach(card => {
  card.addEventListener('click', () => {
    const bigCard = document.querySelector('.studio-card.studio-big');

    if (card !== bigCard) {
      bigCard.classList.remove('studio-big');
      card.classList.add('studio-big');

      // Move clicked card to the start of grid
      grid.prepend(card);
    }
  });
});
